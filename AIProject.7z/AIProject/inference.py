# coding: utf-8
#用于预测、测试模型
from keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D, Lambda, Dropout, SpatialDropout2D, \
    Convolution2D, concatenate, Conv2DTranspose
from keras.models import Model
from keras.models import model_from_json, load_model
import keras.backend as K
import numpy as np
import cv2
import os
import shutil
import random
import json
import time
class Inspect(object):#预测类
    def __init__(self,img_path,save_path,weights_path,area,batch_size,seg_h,seg_w,top_cut,left_cut,height,width,img_type,img_ch) -> object:#初始化
        # self.weight=text['weight']
        self.file = img_path  #预测的图片位置
        self.pre_path = save_path #保存的位置
        self.prob = [127]#概率 0-255
        self.number =[area] #预测要求的面积
        self.label = ['B1'] #预测瑕疵的名字
        self.color = [[0,0,255]] #颜色指定
        self.seg_h = seg_h #切割后的数量，1代表不切
        self.seg_w = seg_w #切割后的数量，1代表不切
        self.top_cut = top_cut #距离图片上方的高度
        self.left_cut = left_cut #距离左边的长度
        self.height = height #切割后的高度
        self.width = width #切割后的宽度
        self.channels = img_ch #输入图片的通道数
        self.Font = cv2.FONT_HERSHEY_SIMPLEX #指定的标注字体
        self.model = self._unet_m(1) #模型的结构
        #载入训练完成的权重文件
        self.model.load_weights(weights_path)
        self.batch_size = batch_size #每批次载入的图片数量，根据GPU的性能选择
        self.img_type = img_type

    def _unet_m(self, n=1):
        inputs = Input((self.height, self.width, self.channels))
        conv1 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(inputs)
        conv1 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(conv1)
        pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)

        conv2 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(pool1)
        conv2 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(conv2)
        pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)

        conv3 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(pool2)
        conv3 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(conv3)
        pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)

        conv4 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(pool3)
        conv4 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(conv4)
        pool4 = MaxPooling2D(pool_size=(2, 2))(conv4)

        conv5 = Conv2D(128 * n, (3, 3), activation='relu', padding='same')(pool4)
        conv5 = Conv2D(128 * n, (3, 3), activation='relu', padding='same')(conv5)

        up6 = concatenate([Conv2DTranspose(64 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv5), conv4],
                          axis=3)
        conv6 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(up6)
        #conv6 = Dropout(0.3)(conv6)
        conv6 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(conv6)

        up7 = concatenate([Conv2DTranspose(32 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv6), conv3],
                          axis=3)
        conv7 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(up7)
        #conv7 = Dropout(0.3)(conv7)
        conv7 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(conv7)

        up8 = concatenate([Conv2DTranspose(32 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv7), conv2],
                          axis=3)
        conv8 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(up8)
        #conv8 = Dropout(0.3)(conv8)
        conv8 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(conv8)

        up9 = concatenate([Conv2DTranspose(16 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv8), conv1],
                          axis=3)
        conv9 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(up9)
        #conv9 = Dropout(0.3)(conv9)
        conv9 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(conv9)

        conv10 = Conv2D(len(self.label) + 1, (1, 1), activation='softmax')(conv9)

        model = Model(inputs=inputs, outputs=conv10)

        return model

    def seg_image(self, image):#切割原圖為小圖
        '''
        切割原圖為預測小圖
        :param image:
        :return:
        '''
        h,w = image.shape[:2]
        if h < self.top_cut + self.height * self.seg_h or w < self.left_cut + self.width * self.seg_w:
            raise ValueError("image should larger than default")

        image = image[self.top_cut: self.top_cut + self.height * self.seg_h,self.left_cut: self.left_cut + self.width * self.seg_w]
        img_seg = np.zeros([self.seg_h * self.seg_w, self.height, self.width, self.channels], dtype=np.float32)

        for i in range(self.seg_h):
            for j in range(self.seg_w):
                img_seg[i * self.seg_w + j] = image[self.height * i:self.height * (i + 1),self.width * j:self.width * (j + 1)]
        img_seg = np.array(img_seg / 255,)
        return (img_seg)

    def ass_mask(self, mask_seg):#合併預測小圖
        '''
        合併預測小圖
        :param mask_seg:
        :return:
        '''
        mask_ass = np.zeros([self.seg_h * self.height, self.seg_w * self.width, len(self.label) + 1], dtype=np.float32)
        for i in range(self.seg_h):
            for j in range(self.seg_w):
                mask_ass[self.height * i:self.height * (i + 1), self.width * j:self.width * (j + 1)] = mask_seg[
                    i * self.seg_w + j]
        return (mask_ass)

    def findContours(self, mask, prob):#找轮廓，将连续的点标注显示，用于计算面积
        _, thre = cv2.threshold((mask * 255).astype(np.uint8), prob, 255, cv2.THRESH_BINARY)#放大到0-255范围进行二值化对比
        _, contours, hir = cv2.findContours(thre, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)#找黑白图，白图代表是，黑图代表不是
        return contours#轮廓的点集

    def infer(self):#预测的方法
        #pred_NG = os.path.join(self.file, 'PB6_NG2')
        #pred_OK = os.path.join(self.file, 'PB6_OK2')
        #if not os.path.exists(pred_NG):
        #    os.mkdir(pred_NG)
        #if not os.path.exists(pred_OK):
        #    os.mkdir(pred_OK)
        #for _ in os.listdir(pred_NG):
        #    os.remove(os.path.join(pred_NG, _))
        #for _ in os.listdir(pred_OK):
        #    os.remove(os.path.join(pred_OK, _))
        #count = 0
        for xx in os.listdir(self.file):
            print(xx)
            if not self.img_type in xx or 'label' in xx: #判断文件是否为图片
                continue
            img = cv2.imdecode(np.fromfile(os.path.join(self.file, xx),np.uint8), 1)
            if img is None:#判断是否为空
                print(xx)
                continue
            if self.channels == 1: #指定是1的话将图片转化为灰度图
                inputs = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                inputs = np.expand_dims(inputs, axis=2)
                inputs = self.seg_image(inputs)
            else:
                inputs = self.seg_image(img)

            pred = self.model.predict(inputs, self.batch_size)#预测
            # pred[1:4,...,1:]=0
            mask = self.ass_mask(pred)#将预测结构拼接成大图
            label = np.zeros((img.shape[0],img.shape[1],3),np.uint8)#保存最终的结果
            for i in range(1, len(self.label) + 1):#根据预测结果在图像上标注
                cts = self.findContours(mask[:, :, i], self.prob[i - 1])#找轮廓
                c_min = []
                for j in range(len(cts)):
                    #x, y, w, h = cv2.boundingRect(cts[j])
                    area = cv2.contourArea(cts[j])#轮廓面积
                    if area > self.number[i - 1]:#如果面积达到最低要求，则是
                        c_min.append(cts[j]) #存储满足条件的轮廓
                #在标注图和原图上draw
                cv2.drawContours(label[self.top_cut: self.top_cut + self.height * self.seg_h,self.left_cut: self.left_cut + self.width * self.seg_w],c_min,-1,[1,0,255],thickness=cv2.FILLED)
                cv2.drawContours(img[self.top_cut: self.top_cut + self.height * self.seg_h,self.left_cut: self.left_cut + self.width * self.seg_w], c_min, -1, [1, 0, 255], thickness=1)
                        #cv2.drawContours(img,cts[j],-1,[0,0,255],2)
                        #cv2.rectangle(img, (x - 5, y - 5), (x + w + 5, y + h + 5), self.color[i - 1], 1)
                        #cv2.putText(frame, self.label[i - 1] + '\\' + str(area), (x - 10, y - 10), self.Font, 0.8,(0, 255, 255), 2)
                        # cv2.putText(frame,self.label[i-1],(x-10,y),self.Font,0.8,self.color[i-1],1)
                        #cv2.putText(frame, str(defect), (10, 20), self.Font, 1, (255, 0, 0), 2)
            #保存图片
            cv2.imencode(self.img_type, img)[1].tofile(os.path.join(self.pre_path, xx))

if __name__ == '__main__':
    ins = Inspect()
    ins.infer()

