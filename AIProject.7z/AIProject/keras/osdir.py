# -*- coding: utf-8 -*-
'''
# @Time    : 2021/11/17 8:31
# @Author  : Leslie Zou
# @Fuction : 输出所有文件和文件夹
'''
import os

# 打开文件
from numpy import unicode

path = "D:/Leslie/Code/unet"
# upath = unicode(path,'utf-8')
dirs = os.listdir( path )
# 输出所有文件和文件夹
for file in dirs:
    print (file)