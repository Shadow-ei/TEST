# -*- coding: utf-8 -*-
import sys
from inference import *
from train2 import *
from utils import *
from h5_to_pb import h5_to_pb
import os
# os.environ['TF_KERAS'] = '1'
sys.path.append(r"C:\Users\Administrator\Desktop\AIProject")  # 将文件更目录加入到项目中
# pip install -i https://pypi.tuna.tsinghua.edu.cn/simple/

def SKTE_ILM(img_h, img_w, img_type, mode):  # 配置该模型的的参数
    if mode == 1:  # 训练模型
        model_name = 'SKTE_ILM_hs'
        path_image = [
            r'F:\AI\74pin_1.3.6\pic\136\ZDLS\label1\B1',
        ]
        save_path = r'F:\AI\74pin_1.3.6\pic\136\ZDLS\label1\res'
        load_weights = False#首次为False，后续皆为True
        load_enhance = False  # 是否进行数据增强
        weights_path = r'D:\AJ\SKTE_ILM_tiemo\SKTE ILM_tiemomian\2023-10-20huashang\res\4\SKTE_ILM_hs_finalWeights.h5' #  上一次训练得到的h5(权重)
        batch_size = 4
        epochs = 200 #训练次数
        learning_rate = 1e-4  # 学习率
        choose_loss = "categorical_crossentropy"  # 损失函数
        # choose_loss = "FocalTverskyLoss"
        overkill_num = 0  # 随机抽取过杀图片加入训练集，无过杀图片则=0
        train_val_rate = 0.8  # 训练集验证集划分比例
        reason = "更新原因：产线反应过杀"
        img_ch = 3  # 训练图的通道数，彩图是三通道=3，灰度图是单通道=1
        main(model_name, path_image, save_path, load_weights, weights_path, img_h, img_w, batch_size, epochs,
             learning_rate, choose_loss, load_enhance, overkill_num, train_val_rate, reason, img_type, img_ch)
    if mode == 2:  # 预测模型
        img_path = r'D:\AJ\SKTE_ILM_tiemo\SKTE ILM_tiemomian'  # 预测图的路径
        save_path = r'D:\AJ\SKTE_ILM_tiemo\SKTE ILM_tiemomian\huashangpre'  # 保存路径
        weights_path = r'D:\AJ\SKTE_ILM_tiemo\SKTE ILM_tiemomian\2023-10-20huashang\res\4\SKTE_ILM_hs_finalWeights.h5'  # 模型路径
        area = 300  # 面积阈值
        batch_size = 8  # 预测模型一次读取图片的数量
        seg_h = 2  # 切割后图片的块数，1代表不切，2代表且切了一刀
        seg_w = 3  # 切割后图片的块数，1代表不切，2代表且切了一刀
        top_cut = 0  # 切割起点距离图片上方的高度
        left_cut = 0  # 切割起点距离左边的长度
        img_ch = 1  # 训练图的通道数，彩图是三通道=3，灰度图是单通道=1
        inspect = Inspect(img_path, save_path, weights_path, area, batch_size, seg_h, seg_w, top_cut, left_cut, img_h,
                          img_w, img_type, img_ch)  # 检测函数
        inspect.infer()  # 推论
    if mode == 3:  # 裁剪图片
        img_path = r'F:\AI\74pin_1.3.6\pic\136\ZDLS\label\B1'  # 原图路径
        save_path = r'F:\AI\74pin_1.3.6\pic\136\ZDLS\label\B1\CUT'  # 保存路径
        img_top = 0  # 切割起点距离图片上方的高度 31
        img_left = 16  # 切割起点距离左边的长度
        seg_h = 2  # 高 切割块数
        seg_w = 2  # 宽 切割块数
        small_h = 1024  # 切割后的高度
        small_w = 1216  # 切割后的宽度
        img_channels = 3
        main_seg_img(img_path, save_path, seg_h, seg_w, img_top, img_left, small_h, small_w, img_type, img_channels)
    if mode == 4:  # 为过杀图生成全黑的label标记图
        img_path = r'D:\AJ\SP5_pad\plus\OK\2023-11-03\CCD1\1\loc\cut'
        save_path = r'D:\AJ\SP5_pad\plus\OK\2023-11-03\CCD1\1\loc\cut'
        # small_h = 720  # 图片高度
        # small_w = 2592  # 图片宽度
        create_label(img_path, save_path, img_h, img_w, img_type)
    if mode == 5:  # 将json文件转化label图
        json_path = r'F:\AI\74pin_1.3.6\pic\136\ZDLS'  # json文件路径
        save_path = r'F:\AI\74pin_1.3.6\pic\136\ZDLS\label1'  # 保存路径
        # seg_h = 4  # height切割块数，metals
        # seg_w = 4  # width切割块数
        seg_h = 1  # height切割块数，pad
        seg_w = 1  # width切割块数
        img_ch = 3
        json_to_mask(json_path, save_path, seg_h, seg_w, img_type, img_ch)
    if mode == 6:  # 将h5模型转化为onnx类型
        model_path = r'D:\AJ\SP5_pad\SP5\data\pad\20231111\res\1\SP5_PadSink_iou0.701-val_iou0.649.h5'
        onnx_path = r'D:\AJ\SP5_pad\SP5\data\pad\20231111\res\1\SP5_PadSink_iou0.701-val_iou0.649.onnx'
        img_channels = 1
        h5_to_onnx(model_path, onnx_path, img_h, img_w, img_channels)
    if mode == 7:  # 将h5模型转化为pb类型
        model_path = r'F:\24E_0617\ccd3\LDl2743SAS_24E38_CCD3_iou0.796-val_iou0.840.h5'
        save_path = r'F:\24E_0617\ccd3\\'
        save_name = '24E38_CCD3_plasticDamage_finalWeights.pb'
        img_ch = 1
        h5_to_pb(model_path, save_path, save_name, img_h, img_w, img_ch)


if __name__ == "__main__":
    # AM5_pad_saturate_hole(2048, 2448, '.bmp', 3)  # 训练图片的高度，宽度，图片类型，功能选择
    SKTE_ILM(2048, 2448, '.bmp', 1)  # 训练图片的高度，宽度，图片类型，功能选择，pad小图尺寸
    # SKTE_ILM(1280, 1280, '.bmp', 5)  # 训练图片的高度，宽度，图片类型，功能选择，metals小图尺寸

"""
运行路径
python D:\AIProject\project\RFKK23\RFKK23_main.py

"""
