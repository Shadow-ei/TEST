# -*- coding: utf-8 -*-
import sys
sys.path.append(r"D:\AIProject")#将文件更目录加入到项目中
from inference import *
from train import *
from utils import *
from h5_to_pb import h5_to_pb

def LDL24E38_CCD5_saturate_hole(img_h,img_w,img_type,mode):#配置该模型的的参数
    if(mode==1):#训练模型
        model_name = 'M2_typec_A1_tonguedamage'#模型名称
        path_image = [r'G:\TypeC_1103\A1_tonguedamage\batch1_0.9_20200102',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_0.9_20200102_cp1',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_0.9_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_0.9_OK',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_1.1_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_1.1_OK',
                      r'G:\TypeC_1103\A1_tonguedamage\batch1_1.32_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch2_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch2_OK',
                      r'G:\TypeC_1103\A1_tonguedamage\batch5_1.32_test_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch7_1.1_0506_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch8_1.1_overkill',
                      r'G:\TypeC_1103\A1_tonguedamage\batch9_1.1_overkill',
                      r'G:\TypeC_1103\A1_tonguedamage\batch10_1.1_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch10_1.1_ok',
                      r'G:\TypeC_1103\A1_tonguedamage\batch11_1.1',
                      r'G:\TypeC_1103\A1_tonguedamage\batch12_1.1_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch13_1.32_NG',
                      r'G:\TypeC_1103\A1_tonguedamage\batch14_0.5_overkill',
                      r'G:\TypeC_1103\A1_tonguedamage\ok_0.9_20210108',
                      r'G:\TypeC_1103\A1_tonguedamage\ok_1.32_20210426',
                      # r'G:\TypeC_1103\A1_tonguedamage\OK_20221105',
                      r'G:\TypeC_1103\A1_tonguedamage\overkill_0.9_1',
                      r'G:\TypeC_1103\CCD1\A1\OK',
                      ]#训练集路径
        save_path = r'G:\TypeC_1103\CCD1\A1\res1'#模型保存路径
        load_weights = True #是否加载权重
        load_enhance = False #是否进行数据增强
        weights_path = r'G:\TypeC_1103\CCD1\A1\A1_tonguedamage1.h5'#权重文件路径
        batch_size = 4 #模型一次读取图片的数量，最好取2的n次方
        epochs = 80 #训练迭代的总次数
        learning_rate = 1e-4  # 学习率
        choose_loss = "categorical_crossentropy"  # 损失函数
        overkill_num = 0  # 随机抽取过杀图片加入训练集，无过杀图片则=0
        train_val_rate = 0.8  # 训练集验证集划分比例
        reason = "更新原因：产线反应过杀"
        img_ch = 3 #训练图的通道数，彩图是三通道=3，灰度图是单通道=1
        main(model_name, path_image, save_path, load_weights, weights_path, img_h, img_w, batch_size, epochs, learning_rate,choose_loss,load_enhance,overkill_num,train_val_rate,reason,img_type,img_ch)
    if(mode==2):#预测模型
        img_path = r'D:\RFKK23_0504\测试图'  # 预测图的路径
        save_path = r'D:\RFKK23_0504\测试图\test'  # 保存路径
        weights_path = r'D:\RFKK23_0504\train_result\RFKK23_CCD2_plasticDamage_finalWeights.h5'  # 模型路径

        # img_path = r'D:\RFKK23_0414\测试图'  # 预测图的路径
        # save_path = r'D:\RFKK23_0414\测试图\test'  # 保存路径
        # weights_path = r'D:\RFKK23_0414\train_result\RFKK23_CCD2_plasticDamage_finalWeights.h5'  # 模型路径


        area = 10 #面积阈值
        batch_size = 8 #预测模型一次读取图片的数量
        seg_h =  1 #切割后图片的块数，1代表不切，2代表且切了一刀
        seg_w = 1 #切割后图片的块数，1代表不切，2代表且切了一刀
        top_cut = 0 #切割起点距离图片上方的高度
        left_cut = 0 #切割起点距离左边的长度
        img_ch = 3 #训练图的通道数，彩图是三通道=3，灰度图是单通道=1
        inspect = Inspect(img_path, save_path, weights_path, area, batch_size, seg_h, seg_w, top_cut, left_cut,img_h,img_w,img_type,img_ch)#检测函数
        inspect.infer() #推论
    if(mode==3):#裁剪图片
        img_path = r'D:\TypeC\CCD1\train\loc' #原图路径
        save_path = r'D:\TypeC\CCD1\train\cut'  # 保存路径
        img_top = 270  #切割起点距离图片上方的高度
        img_left = 376  #切割起点距离左边的长度
        seg_h = 1  # 高 切割块数
        seg_w = 1  # 宽 切割块数
        small_h = 480  # 切割后的高度
        small_w = 1232  # 切割后的宽度
        img_channels = 3
        main_seg_img(img_path,save_path,seg_h,seg_w,img_top,img_left,small_h,small_w,img_type,img_channels)
    if(mode==4):#为过杀图生成全黑的label标记图
        img_path = r'G:\TypeC_1103\CCD1\A1\OK'
        save_path = r'G:\TypeC_1103\CCD1\A1\OK'
        # small_h = 720  # 图片高度
        # small_w = 2592  # 图片宽度
        create_label(img_path,save_path,img_h,img_w,img_type)
    if(mode==5):#将json文件转化label图
        json_path = r'F:\24E38\24E_0719\CCD5\cut' #json文件路径
        save_path = r'F:\24E38\24E_0719\CCD5\label' #保存路径
        seg_h = 1  # height切割块数
        seg_w = 1  # width切割块数
        img_ch = 3
        json_to_mask(json_path, save_path, seg_h, seg_w,img_type,img_ch)
    if(mode==6):#将h5模型转化为onnx类型
        model_path = r'D:\RFKK23_ningyu\RFKK23_0514\train_reslut2\RFKK23_CCD2_ring_finalWeights.h5'
        onnx_path = r'D:\RFKK23_ningyu\RFKK23_0514\train_reslut2\RFKK23_CCD2_ring_finalWeights.onnx'
        img_channels = 3
        h5_to_onnx(model_path,onnx_path,img_h,img_w,img_channels)
    if (mode==7):#将h5模型转化为pb类型
        model_path = r'D:\TypeC\CCD1\train\res\M2_typec_A4_metalxie_finalWeights.h5'
        save_path = r'D:\TypeC\CCD1\train\res\\'
        save_name = 'A4_metalxie.pb'
        img_ch = 3
        h5_to_pb(model_path, save_path, save_name, img_h, img_w, img_ch)
if __name__ == "__main__":
    LDL24E38_CCD5_saturate_hole(128, 832, '.bmp', 1)  # 训练图片的高度，宽度，图片类型，功能选择

"""
运行路径
python D:\AIProject\project\RFKK23\RFKK23_main.py

"""