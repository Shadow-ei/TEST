from PIL import ImageEnhance


import json #
import numpy as np#矩阵操作
from PIL import Image, ImageDraw, ImageEnhance #图像处理库
import cv2 #OpenCV
import os, shutil, io, base64 #图像编码
from skimage.util import random_noise

def img_enhance(path_to_image, path_to_enhance, enh='zd'):
    image_name = [x for x in os.listdir(path_to_image) if x.endswith('_label.bmp')]
    image_num = len(image_name)

    for idx in range(image_num):
        image = Image.open(os.path.join(path_to_image, image_name[idx].replace('_label.bmp', '.bmp')))
        mask = Image.open(os.path.join(path_to_image, image_name[idx]))
        #print(image.mode)
        # image=image.convert("L")
        if enh == 'bri':
            enh_bri = ImageEnhance.Brightness(image)  # 亮度增强
            brightness = 1.2
            image_brightened = enh_bri.enhance(brightness)
            image_brightened.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_bri.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_bri_label.bmp')))

        elif enh == 'con':
            enh_con = ImageEnhance.Contrast(image)  # 对比度增强
            contrast = 1.5
            image_contrasted = enh_con.enhance(contrast)
            image_contrasted.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_con.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_con_label.bmp')))

        elif enh == 'sha':
            enh_sha = ImageEnhance.Sharpness(image)  # 锐度增强
            sharpness = 3.0
            image_sharped = enh_sha.enhance(sharpness)
            image_sharped.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_sha.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_sha_label.bmp')))

        elif enh == 'col':
            enh_col = ImageEnhance.Color(image)  # 色度增强
            color = 1.5
            image_colored = enh_col.enhance(color)
            image_colored.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_col.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_col_label.bmp')))

        elif enh == 'FLR':  # FLIP_LEFT_RIGHT #左右翻转
            image_F = image.transpose(Image.FLIP_LEFT_RIGHT)
            mask_F = mask.transpose(Image.FLIP_LEFT_RIGHT)
            image_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_flr.bmp')))
            mask_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_flr_label.bmp')))

        elif enh == 'FTB':  # FLIP_TOP_BOTTOM #上下翻转
            image_F = image.transpose(Image.FLIP_TOP_BOTTOM)
            mask_F = mask.transpose(Image.FLIP_TOP_BOTTOM)
            image_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_ftb.bmp')))
            mask_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_ftb_label.bmp')))

        elif enh == 'R180':  # ROTATE_180 旋转180度
            image_R = image.transpose(Image.ROTATE_180)
            mask_R = mask.transpose(Image.ROTATE_180)
            image_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r180.bmp')))
            mask_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r180_label.bmp')))

        elif enh == 'R90': #ROTATE_90 旋转90度
            image_R = image.transpose(Image.ROTATE_90)
            mask_R = mask.transpose(Image.ROTATE_90)
            image_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r90.bmp')))
            mask_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r90_label.bmp')))

        elif enh == 'zd':
            image_zd = random_noise(image, 1000)
            image_zd.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_zd.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_zd_label.bmp')))

        else:
            pass
path_to_image = [r'G:\A3_SKT_V\one\Scratch\h0',
                      # r'G:\A3_SKT_V\one\Scratch\OK',
                     ]  # 训练集路径
path_to_enhance = r'G:\A3_SKT_V\one\Scratch\enhance'  # 模型保存路径
img_enhance(path_to_image, path_to_enhance, enh='zd')