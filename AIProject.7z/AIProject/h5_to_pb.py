# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
#训练模型


import os,cv2
import numpy as np
#from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
import time
from keras.models import Model,load_model,model_from_json #keras前端框架，底层调用TensorFlow
from keras.utils import multi_gpu_model
from keras.layers import Input, merge, Conv2D, MaxPooling2D, UpSampling2D,Lambda,Dropout,SpatialDropout2D, Convolution2D, concatenate,Conv2DTranspose
from keras.optimizers import Adam
from keras.callbacks import ModelCheckpoint, CSVLogger, EarlyStopping,ReduceLROnPlateau
from numpy import random
import random
from keras import backend as K
from keras.layers.normalization import BatchNormalization
import tensorflow as tf
import pandas as pd
import os.path as osp
import tensorflow as tf
import os
import keras.backend as K

def unet_m(img_h, img_w, img_channels, label_channels):#高、宽、图片通道数、输出的类别数
    inputs = Input((img_h, img_w, img_channels))
    conv1 = Conv2D(8, (3, 3), activation='relu', padding='same')(inputs)#8个卷积核、卷积核的尺寸、激活函数、零填充
    conv1 = Conv2D(8, (3, 3), activation='relu', padding='same')(conv1)
    pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)

    conv2 = Conv2D(16, (3, 3), activation='relu', padding='same')(pool1)
    conv2 = Conv2D(16, (3, 3), activation='relu', padding='same')(conv2)
    pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)

    conv3 = Conv2D(32, (3, 3), activation='relu', padding='same')(pool2)
    conv3 = Conv2D(32, (3, 3), activation='relu', padding='same')(conv3)
    pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)

    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same')(pool3)
    conv4 = Conv2D(64, (3, 3), activation='relu', padding='same')(conv4)
    pool4 = MaxPooling2D(pool_size=(2, 2))(conv4)

    conv5 = Conv2D(128, (3, 3), activation='relu', padding='same')(pool4)
    conv5 = Conv2D(128, (3, 3), activation='relu', padding='same')(conv5)

    up6 = concatenate([Conv2DTranspose(64, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv5), conv4],
                      axis=3)
    conv6 = Conv2D(64, (3, 3), activation='relu', padding='same')(up6)
    conv6 = Conv2D(64, (3, 3), activation='relu', padding='same')(conv6)
    up7 = concatenate([Conv2DTranspose(32, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv6), conv3],
                      axis=3)
    conv7 = Conv2D(32, (3, 3), activation='relu', padding='same')(up7)
    conv7 = Conv2D(32, (3, 3), activation='relu', padding='same')(conv7)
    up8 = concatenate([Conv2DTranspose(32, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv7), conv2],
                      axis=3)
    conv8 = Conv2D(16, (3, 3), activation='relu', padding='same')(up8)
    conv8 = Conv2D(16, (3, 3), activation='relu', padding='same')(conv8)
    up9 = concatenate([Conv2DTranspose(16, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv8), conv1],
                      axis=3)
    conv9 = Conv2D(8, (3, 3), activation='relu', padding='same')(up9)
    conv9 = Conv2D(8, (3, 3), activation='relu', padding='same')(conv9)
    conv10 = Conv2D(label_channels, (1, 1), activation='softmax')(conv9)#输出的图 OK or NG，为什么不用sigmoid

    model = Model(inputs=inputs, outputs=conv10)

    return model
def to_pb(h5_model,output_dir,model_name,out_prefix = "output_",log_tensorboard = True):
    if osp.exists(output_dir) == False:
        os.mkdir(output_dir)
    out_nodes = []
    for i in range(len(h5_model.outputs)):
        out_nodes.append(out_prefix + str(i + 1))
        tf.identity(h5_model.output[i],out_prefix + str(i + 1))
    sess = K.get_session()
    from tensorflow.python.framework import graph_util,graph_io
    init_graph = sess.graph.as_graph_def()
    main_graph = graph_util.convert_variables_to_constants(sess,init_graph,out_nodes)
    graph_io.write_graph(main_graph,output_dir,name = model_name,as_text = False)
    if log_tensorboard:
        from tensorflow.python.tools import import_pb_to_tensorboard
        import_pb_to_tensorboard.import_to_tensorboard(osp.join(output_dir,model_name),output_dir)

def h5_to_pb(model_path: object, save_path: object, save_name: object, img_h: object, img_w: object, img_channels: object) -> object:

    label_channels = 2
    PSmodel = unet_m(img_h, img_w, img_channels, label_channels)
    PSmodel.load_weights(model_path)

    print('Starting Translate HDF5 to PB!')
    to_pb(PSmodel, save_path, save_name)
    print('Finish Translation!')


def FocalTverskyLoss(targets, inputs, alpha=0.4, beta=0.6, gamma=2, smooth=0.001):  #
        # flatten label and prediction tensors
        inputs = K.flatten(inputs[..., 1:])
        targets = K.flatten(targets[..., 1:])

        # True Positives, False Positives & False Negatives
        TP = K.sum((inputs * targets))
        FP = K.sum(((1 - targets) * inputs))
        FN = K.sum((targets * (1 - inputs)))

        Tversky = (TP + smooth) / (TP + alpha * FP + beta * FN + smooth)
        FocalTversky = K.pow((1 - Tversky), gamma)

        return FocalTversky

class AI_train():
    def __init__(self, img_type,path_image, n_class, save_path, img_ch, img_h, img_w,batch_size, model_name,load_weights, prev_weights, epochs, ini_epo,learning_rate,choose_loss,load_enhance,overkill_num, train_val_rate,loss_f=1, n_gpu=1):#初始化类
        self.img_type = img_type#图片类型
        self.path_image = path_image#图片的位置
        self.save_path = save_path#项目文件的位置
        self.img_channels = img_ch#图片的通道 灰度图或者彩图
        self.img_h = img_h #图片的高度
        self.img_w = img_w  #图片的宽度
        self.label_channels = n_class #类别数
        self.batch_size = batch_size #一次加载训练的图片数量
        self.model_name = model_name #模型名字，一般与项目名字一样
        self.load_weights = load_weights  #是否加载权重
        self.prev_weights = prev_weights #预加载权重的文件
        self.epochs = epochs #每轮训练迭代的次数
        self.ini_epo = ini_epo #初始迭代的次数，从哪一次开始
        self.loss_f = loss_f #默认是1，用哪个损失函数
        self.n_gpu = n_gpu #默认是1，GPU数量
        self.learning_rate = learning_rate #学习率
        self.choose_loss = choose_loss #损失函数
        self.load_enhance = load_enhance #数据增强
        self.overkill_num = overkill_num #过杀数
        self.train_val_rate = train_val_rate #训练集验证集划分比例

    def train(self):#模型训练
        self.label_name_train, self.label_name_val = self.count_image()#分成训练集和验证集
        print('train:', len(self.label_name_train))
        print('val:', len(self.label_name_val))
        test = pd.DataFrame(self.label_name_train)
        test.to_csv(os.path.join(self.save_path+"\\logs", 'data_list_for_train.csv'), encoding='utf-8')
        test2 = pd.DataFrame(self.label_name_val)
        test2.to_csv(os.path.join(self.save_path+"\\logs", 'data_list_for_valid.csv'), encoding='utf-8')#将训练集和验证集写入CSV文件内
        self.model = self.unet_m()#定义模型，实例化一个模型
        t_m = time.strftime('%Y%m%d_%H%M', time.localtime(time.time()))#当前的时间
        if(self.load_weights):
            try:
                self.model.load_weights(os.path.join(self.prev_weights))#是否预加载权重
                print("加载模型成功，继续训练模型")
            except:
                print("加载模型失败，开始训练一个新模型")#保存最佳权重
        self.best_weights = os.path.join(self.save_path,self.model_name + '_iou{IOU_calc:.3f}-val_iou{val_IOU_calc:.3f}' + '.h5')  # 只保留最佳权重，不需要每个都保留
        self.final_weights = os.path.join(self.save_path, self.model_name + '_finalWeights.h5')  # 最终的权重
        self.architecture = os.path.join(self.save_path, self.model_name + '_architecture.json')#保存的模型结构，用json文件存储
        self.final_model = os.path.join(self.save_path, self.model_name + '_model.h5')#最终保存的模型，包括权重、结构等
        self.logger = CSVLogger(os.path.join(self.save_path +"\\logs", self.model_name + '_' + t_m + '.log'))#运行的日志文件
        self.reduce_lr = ReduceLROnPlateau(monitor='loss', factor=0.1, patience=50, verbose=1) #是否调整学习速率
                              # 回调函数 最佳权重文件路径  判断指标          进度条显示,0不显示    是否只保留最佳权重
        self.callbacks_list = [
            ModelCheckpoint(self.best_weights, monitor='val_IOU_calc', verbose=1, save_best_only=True,
                            save_weights_only=True, mode='max'), self.logger, self.reduce_lr]
                              #是否只保留权重                        日志文件夹
        # callbacks_list = [MyModelCheckpoint(self.model_result, self.best_weights),self.logger,self.reduce_lr]
        if self.n_gpu == 1: #gpu数量判断
            if self.loss_f == 1 and self.label_channels > 1: #如果选择第一种损失函数并且多分类
                if(self.choose_loss == "categorical_crossentropy"):
                    self.model.compile(optimizer=Adam(lr=self.learning_rate), loss="categorical_crossentropy", metrics=[self.IOU_calc]) #模型编译配置 优化器 损失函数交叉熵 评估矩阵（自定义的交并比函数评估）
                else:
                    self.model.compile(optimizer=Adam(lr=self.learning_rate), loss=self.choose_loss, metrics=[self.IOU_calc]) #模型编译配置 优化器 损失函数交叉熵 评估矩阵（自定义的交并比函数评估）
            else:
                self.model.compile(optimizer=Adam(lr=self.learning_rate), loss="binary_crossentropy", metrics=[self.IOU_calc])#损失函数为二分类
                #开始训练 拟合模型                      #生成器图片 image_batch：训练集的所有label图片路径 是否数据增强 计算每批次的图片训练数量 epochs：迭代次数 进度条 initial_epoch： 初始迭代位置 label_name_val：验证集
            self.history = self.model.fit_generator(generator=self.image_batch(self.label_name_train,is_enhance = False),steps_per_epoch=(len(self.label_name_train) + self.batch_size - 1) // self.batch_size,
            epochs=self.epochs,verbose=1, initial_epoch=self.ini_epo,validation_data=self.image_batch(self.label_name_val,is_enhance = False),
            validation_steps=(len(self.label_name_val) + self.batch_size - 1) // self.batch_size,callbacks=self.callbacks_list)
            #指定yield返回次数,图片总数/batch_size向上取整即可求得                                                                           回调函数，继续调用fit_generator函数
        elif self.n_gpu == 2:
            self.parallel_model = multi_gpu_model(self.model, gpus=2)
            if self.loss_f == 1 and self.label_channels > 2:
                self.parallel_model.compile(optimizer=Adam(lr=self.learning_rate), loss=self.choose_loss,metrics=[self.IOU_calc])
            else:
                self.parallel_model.compile(optimizer=Adam(lr=self.learning_rate), loss=self.IOU_calc_loss, metrics=[self.IOU_calc])
            self.history = self.parallel_model.fit_generator(generator=self.image_batch(self.label_name_train,is_enhance = False),
                                                             steps_per_epoch=(len(self.label_name_train) + self.batch_size - 1) // self.batch_size,
                                                             epochs=self.epochs,
                                                             verbose=1,
                                                             validation_data=self.image_batch(self.label_name_val,is_enhance = False),
                                                             validation_steps=(len(self.label_name_val) + self.batch_size - 1) // self.batch_size,
                                                             callbacks=self.callbacks_list)
        self.json_string = self.model.to_json()#将模型保存为json文件
        open(self.architecture, 'w').write(self.json_string)#
        self.model.save_weights(self.final_weights)#模型保存为最终的权重
        self.model.save(self.final_model) #保存最终的模型
        return ('train finished')#训练结束

    def count_image(self):  # 图片分成训练集、验证集 4:1
        label_name_train = []
        label_name_val = []
        print("训练集验证集划分：")
        for _ in self.path_image:  # 遍历每個子文件夾
            names = [x for x in os.listdir(_) if x.endswith('label'+self.img_type)]  # 遍历每個子文件的标注图
            print("文件夹样本总数：", len(names))
            np.random.shuffle(names)  # 随机打乱所有图片顺序
            # if "OK" in _:
            #     names = names[:self.overkill_num]
            # if "Overkill" in _:
            #     names = names[:self.overkill_num]
            num = len(names)  # 每个文件夹图片的数量
            if "20220408train" in _:  # 将图片指定为训练集
                for name in names:  # 遍历图片
                    filename = os.path.join(_, name)
                    label_name_train.append(filename)
                print(_, "图片数=", len(names), "训练集数目=", num, "验证集数目=0")  #
            else:
                if num > 0:
                    count = 0
                    train_num = 0
                    for name in names:  # 遍历图片
                        count += 1
                        filename = os.path.join(_, name)
                        if count <= 5 or count <= int(num * self.train_val_rate):  # 总数的前80%用于训练集，最后面的20%用于验证集
                            label_name_train.append(filename)
                            train_num = train_num + 1
                        else:
                            label_name_val.append(filename)
                print(_, "图片数=", len(names), "训练集数目=", train_num, "验证集数目=", len(names) - train_num)  #
        print("图片总数", len(label_name_train) + len(label_name_val), "训练集总数=", len(label_name_train), "验证集总数=",len(label_name_val))
        np.random.shuffle(label_name_train)  # 随机打乱文件夹顺序
        np.random.shuffle(label_name_val)  # 随机打乱列表顺序
        return label_name_train, label_name_val
    def image_batch(self, label_name,is_enhance):  # 产生循环批量读取，分批次读取图片
        label_num = len(label_name) #每批次的图片数量
        batchs = (label_num + self.batch_size - 1) // self.batch_size #加上一个batch_size-1是为了最后整除向上取整，否则batchs会不够
        while True:
            for i in range(batchs):
                batch_start = i * self.batch_size
                batch_end = (i + 1) * self.batch_size
                if batch_end > label_num:#如果batch_end超过了总的label数量，则将batch_end设置为数据集的最后一个
                    batch_end = label_num
                x, y = self.load_image_label_batch(label_name, batch_start, batch_end,is_enhance)# X是一个列表shape=(12,992,800,1)里面有batch_size 12个原图数据，Y也是列表shape=(12,992,800,2)，里面有12个label数据，
                                                                                                                                                 # 其中第0层存放无瑕疵数据(有瑕疵为为0，无瑕疵为1，即黑图为1)，第1层存放瑕疵数据：(有瑕疵为1，即有标注，无瑕疵为0）
                yield (x, y)#得到图片的矩阵 带有yield的函数不是普通函数，是一个生成器，每次执行到此处会返回值给调用处，然后调用处的generator后再一次调用这个函数，然后继续从yield的下一步开始执行

    def load_image_label_batch(self, label_name, batch_start, batch_end,is_enhance):#载入一batch图片
        image = np.zeros([batch_end - batch_start, self.img_h, self.img_w, self.img_channels], dtype=np.float32) #shape(batch_size,h,w,c)比如(12,992,800,1)
        label = np.zeros([batch_end - batch_start, self.img_h, self.img_w, self.label_channels], dtype=np.float32)
        for i in range(batch_end - batch_start):
            if self.img_channels == 1:#通道数判断 读成灰度图 一般是运行这个↓
                #读取原图数据，只需要将label_name里存的label标签名称改为.bmp即可使用绝对路径访问到原图,因为原图和标注图是放在一块的 img维度是(992,800)
                img = cv2.imdecode(np.fromfile(label_name[i + batch_start].replace('_label'+self.img_type, self.img_type),dtype=np.uint8), 0)#imdecode,解码函数，一般是读取图片数据 encode是编码函数，是写入图片
            else: #BGR图
                img = cv2.imdecode(np.fromfile(label_name[i + batch_start].replace('_label'+self.img_type, self.img_type),dtype=np.uint8), 1)
            mask = cv2.imdecode(np.fromfile(label_name[i + batch_start], dtype=np.uint8), 1)#直接读取标注图label
            if img is None or mask is None:
                print(label_name[i + batch_start])
            if(self.load_enhance):#如果添加图像增强
                Aug_choices_list = [0, 1, 2, 3]  # 进行四种方式的随机增强，还有一个是不作处理
                Aug_choice = random.sample(Aug_choices_list, 1)[0]  # 随机生成一个Aug_choices_list中的数字
                # Aug_choice=2
                if Aug_choice == 0:  # 平移
                    xlist = list(range(-15, 15, 1))  # 在-15~15个像素点范围内平移
                    ylist = list(range(-15, 15, 1))
                    tr_x = random.sample(xlist, 1)[0]
                    tr_y = random.sample(ylist, 1)[0]
                    M = np.float32([[1, 0, tr_x], [0, 1, tr_y]])  # 变换矩阵,此处平移x,y个像素
                    img = cv2.warpAffine(img, M, (img.shape[1], img.shape[0]))  # 输入图像,变换矩阵,输出图像大小 宽 高 ,
                    mask = cv2.warpAffine(mask, M, (img.shape[1], img.shape[0]))
                elif Aug_choice == 1:  # 旋转
                    angle_list = list(range(-5, 5, 1))  # 在-3度和3度之间旋转
                    angle = random.sample(angle_list, 1)[0]
                    img = self.rotate(img, angle)  # 直接旋转
                    mask = self.rotate(mask, angle)
                elif Aug_choice == 2:  # 对比度和亮度
                    lb = list(range(-10, 10, 1))  # 亮度范围-10~10
                    # lc = list(np.arange(0.95, 1.1, 0.01))  #
                    # lc = list(np.arange(0.65, 1.2, 0.01))  #
                    lc = list(np.arange(0.85, 1.2, 0.01))  #
                    b = random.sample(lb, 1)[0]  # 随机选取一个增强度数
                    c = random.sample(lc, 1)[0]  # 随机选取一个图像融合比例,是和纯黑图进行融合
                    img = self.contrast_img(img, c, b)
            if (self.img_channels == 1):
                img = np.expand_dims(img, axis=2)#shape=(992,800,1)给数组加一个维度，位置为axis=2  如果原来的维度为(x,y) axis=2 则维度变为(x,y,1)-->axis=1-->维度变为(x,1,y,1) 总之就是在axis处添加一个一维的维度
            img = np.array(img / 255., dtype=np.float32)  # 图片归一化
            image[i] = img #1，根据label_name读取原图,然后添加第三个channel维度,然后归一化,最后赋值给image回传给调用处
            if self.label_channels > 1:#多分类，运行这个↓
                for j in range(self.label_channels):
                    label[i][:, :, j] = np.where(mask[:, :, 0] == j, 1, 0)  # 无缺陷放在label0层, 缺陷1放在label1层...  np.where表示如果满足，则输出x，否则输出y
            else:#二分类
                label[i][:, :, 0] = np.where(mask[:, :, 0] == 1, 1, 0)  # 无缺陷放在label0层, 缺陷都放在label1层... 即阴性样本放在0层，阳性样本放在1层
        return (image, label)#模型的输入，原图，标注图


    def rotate(self, img, angle):  # 旋转增强
        rows, cols = img.shape[:2]
        center_coordinate = (int(cols / 2), int(rows / 2))
        M = cv2.getRotationMatrix2D(center_coordinate, angle, 1)
        # 仿射变换
        out_size = (cols, rows)
        rotate_img = cv2.warpAffine(img, M, out_size, borderMode=cv2.BORDER_REPLICATE)
        return rotate_img

    def contrast_img(self, img1, c, b):  # 对比度增强 亮度就是每个像素所有通道都加上b
        rows, cols = img1.shape
        blank = np.zeros([rows, cols], img1.dtype)  # 生成一个同等大小的纯黑图
        dst = cv2.addWeighted(img1, c, blank, 1 - c, b)  # 图片融合,(图片1,融合比例,图片2,,融合比例,亮度值)
        return dst

    def unet_m(self, ):#多分类
        #inputs = Input((IMAGE_HEIGHT, IMAGE_WIDTH, IMAGE_CHANNELS))
        inputs = Input((self.img_h, self.img_w, self.img_channels))
        #     inputs_norm = Lambda(lambda x: x/127.5 - 1.)
        conv1 = Conv2D(8, (3, 3), activation='relu', padding='same')(inputs)
        conv1 = Conv2D(8, (3, 3), activation='relu', padding='same')(conv1)
        pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)

        conv2 = Conv2D(16, (3, 3), activation='relu', padding='same')(pool1)
        conv2 = Conv2D(16, (3, 3), activation='relu', padding='same')(conv2)
        pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)

        conv3 = Conv2D(32, (3, 3), activation='relu', padding='same')(pool2)
        conv3 = Conv2D(32, (3, 3), activation='relu', padding='same')(conv3)
        pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)

        conv4 = Conv2D(64, (3, 3), activation='relu', padding='same')(pool3)
        conv4 = Conv2D(64, (3, 3), activation='relu', padding='same')(conv4)
        pool4 = MaxPooling2D(pool_size=(2, 2))(conv4)

        conv5 = Conv2D(128, (3, 3), activation='relu', padding='same')(pool4)
        conv5 = Conv2D(128, (3, 3), activation='relu', padding='same')(conv5)

        up6 = concatenate([Conv2DTranspose(64, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv5), conv4],
                          axis=3)
        conv6 = Conv2D(64, (3, 3), activation='relu', padding='same')(up6)
        conv6 = Dropout(0.3)(conv6)
        conv6 = Conv2D(64, (3, 3), activation='relu', padding='same')(conv6)

        up7 = concatenate([Conv2DTranspose(32, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv6), conv3],
                          axis=3)
        conv7 = Conv2D(32, (3, 3), activation='relu', padding='same')(up7)
        conv7 = Dropout(0.3)(conv7)
        conv7 = Conv2D(32, (3, 3), activation='relu', padding='same')(conv7)

        up8 = concatenate([Conv2DTranspose(32, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv7), conv2],
                          axis=3)
        conv8 = Conv2D(16, (3, 3), activation='relu', padding='same')(up8)
        conv8 = Dropout(0.3)(conv8)
        conv8 = Conv2D(16, (3, 3), activation='relu', padding='same')(conv8)

        up9 = concatenate([Conv2DTranspose(16, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv8), conv1],
                          axis=3)
        conv9 = Conv2D(8, (3, 3), activation='relu', padding='same')(up9)
        conv9 = Dropout(0.3)(conv9)
        conv9 = Conv2D(8, (3, 3), activation='relu', padding='same')(conv9)

        #conv10 = Conv2D(label_CHANNELS, (1, 1), activation='softmax')(conv9)
        conv10 = Conv2D(self.label_channels, (1, 1), activation='softmax')(conv9)

        model = Model(inputs=inputs, outputs=conv10)

        return model

    def unet_b(self, n=1): #二分类
        inputs = Input((self.img_h, self.img_w, self.img_channels))
        conv1 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(inputs)
        conv1 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(conv1)
        pool1 = MaxPooling2D(pool_size=(2, 2))(conv1)

        conv2 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(pool1)
        conv2 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(conv2)
        pool2 = MaxPooling2D(pool_size=(2, 2))(conv2)

        conv3 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(pool2)
        conv3 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(conv3)
        pool3 = MaxPooling2D(pool_size=(2, 2))(conv3)

        conv4 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(pool3)
        conv4 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(conv4)
        pool4 = MaxPooling2D(pool_size=(2, 2))(conv4)

        conv5 = Conv2D(128 * n, (3, 3), activation='relu', padding='same')(pool4)
        conv5 = Conv2D(128 * n, (3, 3), activation='relu', padding='same')(conv5)

        up6 = concatenate([Conv2DTranspose(64 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv5), conv4],
                          axis=3)
        conv6 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(up6)
        conv6 = Dropout(0.3)(conv6)
        conv6 = Conv2D(64 * n, (3, 3), activation='relu', padding='same')(conv6)

        up7 = concatenate([Conv2DTranspose(32 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv6), conv3],
                          axis=3)
        conv7 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(up7)
        conv7 = Dropout(0.3)(conv7)
        conv7 = Conv2D(32 * n, (3, 3), activation='relu', padding='same')(conv7)

        up8 = concatenate([Conv2DTranspose(32 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv7), conv2],
                          axis=3)
        conv8 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(up8)
        conv8 = Dropout(0.3)(conv8)
        conv8 = Conv2D(16 * n, (3, 3), activation='relu', padding='same')(conv8)

        up9 = concatenate([Conv2DTranspose(16 * n, kernel_size=(2, 2), strides=(2, 2), padding='same')(conv8), conv1],
                          axis=3)
        conv9 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(up9)
        conv9 = Dropout(0.3)(conv9)
        conv9 = Conv2D(8 * n, (3, 3), activation='relu', padding='same')(conv9)

        conv10 = Conv2D(self.label_channels, (1, 1), activation='sigmoid')\
            (conv9)#激活函数sigmoid

        model = Model(inputs=inputs, outputs=conv10)
        return model

    def IOU_calc(self, y_true, y_pred):#计算交并集的比值，模型评估   自定义损失函数
        y_true_f = K.flatten(y_true[...,1: ])
        y_pred_f = K.flatten(y_pred[...,1: ])
        intersection = K.sum(y_true_f * y_pred_f)

        return (2. * intersection + 0.001) / (K.sum(y_true_f) + K.sum(y_pred_f) + 0.001)

    def IOU_calc_loss(self, y_true, y_pred):#损失函数，加上负号
        return -self.IOU_calc(y_true, y_pred)
    def FocalTverskyLoss(self,targets, inputs, alpha=0.45, beta=0.55, gamma=2, smooth=0.001):  # 以上两种方式结合的loss
        # flatten label and prediction tensors
        inputs = K.flatten(inputs[..., 1:])
        targets = K.flatten(targets[..., 1:])

        # True Positives, False Positives & False Negatives
        TP = K.sum((inputs * targets))
        FP = K.sum(((1 - targets) * inputs))
        FN = K.sum((targets * (1 - inputs)))

        Tversky = (TP + smooth) / (TP + alpha * FP + beta * FN + smooth)
        FocalTversky = K.pow((1 - Tversky), gamma)

        return FocalTversky

    def show(self):#训练结果展示，可视化展现
        a = 0
        for i in self.label_name_val:
            if a < 10:
                a += 1
                if self.img_channels == 1:
                    raw_img = cv2.imdecode(np.fromfile(i.replace('_label'+self.img_type,self.img_type),dtype=np.uint8), 0)
                    img = np.zeros((1, raw_img.shape[0], raw_img.shape[1], 1), dtype=np.float32)
                    img[0,:,:,0] = raw_img / 255
                else:
                    raw_img = cv2.imdecode(np.fromfile(i.replace('_label'+self.img_type, self.img_type), dtype=np.uint8), 1)
                    img = np.zeros((1, raw_img.shape[0], raw_img.shape[1],3), dtype=np.float32)
                    img[0] = raw_img / 255
                mask = cv2.imdecode(np.fromfile(i,dtype=np.uint8), 1)
                infer_img = self.model.predict(img)
                infer_img = np.argmax(infer_img, axis=-1)
                #         if len(np.unique(infer_img)) == 1:
                #             continue
                #         else:
                plt.figure(figsize=(20, 20))
                plt.subplot(1, 3, 1)
                plt.title(a)
                plt.imshow(raw_img,'gray')
                plt.subplot(1, 3, 2)
                plt.imshow(mask)
                plt.subplot(1, 3, 3)
                plt.title(np.unique(infer_img))
                plt.imshow(infer_img[0, :, :], cmap='jet')
                plt.show()

    def draw_p(self, i):#可视化函数
        # print(self.history.history['IOU_calc'])
        plt.figure(figsize=(20, 5))
        plt.plot(self.history.history['IOU_calc'], label='Train IOU')
        plt.plot(self.history.history['val_IOU_calc'], label='Val IOU')
        plt.xlabel('Epochs')

        plt.ylabel('IOU')
        plt.legend()
        plt.savefig(os.path.join(self.save_path+"\\logs", str(i)+'_res.png'))
        #plt.show()

def main(model_name,path_image,save_path,load_weights,weights_path,img_h,img_w,batch_size,epochs,learning_rate,choose_loss,load_enhance,overkill_num,train_val_rate,reason,img_type,img_ch):#配置该项目的参数
    logs = os.path.exists(save_path + "\\logs")
    if not logs:
        os.makedirs(save_path + "\\logs", )
    readme = open(save_path + "\\logs\\readme.txt", 'w', encoding="utf-8")
    readme.write(reason)
    readme.close()
    # img_ch = 3
    n_class = 2
    ini_epo = 0
    loss_f = 1
    n_gpu = 1
    for i in range(0,1):
        training = AI_train(img_type,path_image, n_class, save_path, img_ch, img_h, img_w, batch_size, model_name,load_weights,weights_path, epochs, ini_epo,learning_rate,choose_loss,load_enhance,overkill_num,train_val_rate,loss_f, n_gpu,)#实例化AI_train
        res = training.train()#调用训练模型
        training.draw_p(i)#展示
        del(training)
        print(res)
