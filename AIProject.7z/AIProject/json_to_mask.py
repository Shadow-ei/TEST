# -*- coding: utf-8 -*-
'''
# @Time    : 2021/12/23 15:46
# @Author  : Leslie Zou
# @Fuction : 
'''
import argparse
import json
import matplotlib.pyplot as plt
import numpy as np
from IPython.display import Image
import PIL.Image
import PIL.ImageDraw
# import xmltodict
from collections import Counter
import cv2
import os, os.path,shutil
import sys
import base64
import io
from imageio import imread
import glob
def img_b64_to_arr(img_b64):
    f = io.BytesIO()
    f.write(base64.b64decode(img_b64))
    img_arr = np.array(PIL.Image.open(f))
    return img_arr
def json_label_to_img_mask(raw_json_path, label_class):
    with open(raw_json_path, errors='ignore') as f:
        json_data = json.load(f)  # 加载json文件的数据内容
        img_path = json_data['imagePath']  # 读取json文件中对应的img原图
        img_type = img_path[-4:]  # 读取类型 img_type:'.bmp'
        img_data = PIL.Image.open(raw_json_path.replace('.json', img_type))
        img_data = np.array(img_data)  # 为img图片路径创建numpy数组信息
        mask = np.zeros(img_data.shape[:2], dtype=np.uint8)  # 根据图片的width和height创建全黑label图
        mask = PIL.Image.fromarray(mask)  # 将array转换成image  将img转化为array：img = np.asarray(image)
        a = 1
        for shape in json_data['shapes']:
            points = shape['points']  # 读取json文件中描绘的点集
            xy = list(map(tuple, points))  # 用元组存储点集
            label = shape['label']  # 读取标签类型'B1'
            shape_type = label_class[label]  # label_class = {'B1':1,'B2':2} 这里label索引为'B1',故shape_type=1
            if len(points) == 2:
                PIL.ImageDraw.Draw(mask).rectangle(xy[0] + xy[1], outline=shape_type, fill=shape_type)
            if len(points) > 2:
                PIL.ImageDraw.Draw(mask).polygon(xy=xy, outline=shape_type, fill=shape_type)  # 在mask中画图
            a += 1
        mask = np.array(mask, dtype=int)
    return img_data, mask

def json_to_mask(json_path,save_path,seg_h,seg_w):
    IMAGE_CHANNELS = 1
    label_class = {'B1':1,'B2':2}
    raw_json_path = r'D:\Leslie\Project\SKTV_E\Data\CCD1\left\mask'
    save_cutted_pic_path = r'D:\Leslie\Project\SKTV_E\Data\CCD1\left\mask\label'
    image_name = os.listdir(raw_json_path)
    image_name = [x for x in image_name if x.endswith('.json')]
    print(len(image_name))
    print(image_name[0])
    m = 1
    for _ in range(len(image_name)):
        img_data, mask = json_label_to_img_mask(os.path.join(raw_json_path, image_name[_]), label_class)
        img_height = int(img_data.shape[0] / 2)
        img_width = int(img_data.shape[1] / 4)
        a = 1
        for i in range(2):
            for j in range(4):
                small_pic = img_data[i * img_height:(i + 1) * img_height, j * img_width:(j + 1) * img_width]
                small_mask = mask[i * img_height:(i + 1) * img_height, j * img_width:(j + 1) * img_width]
                if len(np.unique(small_mask)) == 1:
                    print(m)
                    m += 1
                    path = os.path.join(save_cutted_pic_path, 'ok')
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', '.png'), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label.png'), small_mask)
                elif len(np.unique(small_mask)) == 2:
                    print(m)
                    m += 1
                    color_small_mask = np.zeros((img_height, img_width, 3), dtype=np.uint8)
                    color_small_mask[:, :, 0] = small_mask
                    ### 1===red
                    color_small_mask[:, :, 1][np.where(small_mask == 1)] = 0
                    color_small_mask[:, :, 2][np.where(small_mask == 1)] = 255
                    #          2==green
                    color_small_mask[:, :, 1][np.where(small_mask == 2)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 2)] = 0
                    #          3== yellow
                    color_small_mask[:, :, 1][np.where(small_mask == 3)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 3)] = 255
                    #          4== 粉红
                    color_small_mask[:, :, 1][np.where(small_mask == 4)] = 100
                    color_small_mask[:, :, 2][np.where(small_mask == 4)] = 255

                    color_small_mask[:, :, 1][np.where(small_mask == 5)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 5)] = 100
                    class_type = list(label_class.keys())[list(label_class.values()).index(np.unique(small_mask)[1])]

                    path = os.path.join(save_cutted_pic_path, class_type)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', '.png'), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label.png'), color_small_mask)
                else:
                    print(m)
                    m += 1
                    color_small_mask = np.zeros((img_height, img_width, 3), dtype=np.uint8)
                    color_small_mask[:, :, 0] = small_mask

                    ### 1===red
                    color_small_mask[:, :, 1][np.where(small_mask == 1)] = 0
                    color_small_mask[:, :, 2][np.where(small_mask == 1)] = 255
                    #          2==green
                    color_small_mask[:, :, 1][np.where(small_mask == 2)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 2)] = 0
                    #          3== yellow
                    color_small_mask[:, :, 1][np.where(small_mask == 3)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 3)] = 255
                    #          4== 粉红
                    color_small_mask[:, :, 1][np.where(small_mask == 4)] = 100
                    color_small_mask[:, :, 2][np.where(small_mask == 4)] = 255
                    #          4== red
                    color_small_mask[:, :, 1][np.where(small_mask == 5)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 5)] = 100
                    path = os.path.join(save_cutted_pic_path, 'mulit_type')
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', '.png'), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label.png'), color_small_mask)
                a += 1