# coding: utf-8

import tensorflow as tf
import os
from keras import backend as K
from tensorflow.python.framework import graph_util,graph_io
from train import unet_m
import keras2onnx
import onnx

def load_graph(model_dir):
    '''
    生成計算圖
    :param model_dir: pb文件
    :return:
    '''
    with tf.gfile.GFile(model_dir, "rb") as f:  # 读取模型数据
        graph_def = tf.GraphDef()
        graph_def.ParseFromString(f.read())  # 得到模型中的计算图和数据

    with tf.Graph().as_default() as graph:  # 这里的Graph()要有括号，不然会报TypeError
        tf.import_graph_def(graph_def)  # 导入模型中的图到现在这个新的计算图中，不指定名字的话默认是 import
    return graph


def h5_to_pb(h5_model, output_dir, model_name, out_prefix = 'output_', log_tensorboard = True):
    '''
    生成pb
    :param h5_model:
    :param output_dir:
    :param model_name:
    :param out_prefix:
    :param log_tensorboard:
    :return:
    '''
    #if os.path.exists(output_dir) == False:
	#	os.mkdir(output_dir)
    out_nodes = []
    for i in range(len(h5_model.outputs)):
        out_nodes.append(out_prefix + str(i+1))
        tf.identity(h5_model.output[i], out_prefix + str(i+1))
    sess = K.get_session()
    init_graph = sess.graph.as_graph_def()
    main_graph = graph_util.convert_variables_to_constants(sess,init_graph,out_nodes)
    graph_io.write_graph(main_graph,output_dir,name = model_name,as_text = False)
    if log_tensorboard:
        from tensorflow.python.tools import import_pb_to_tensorboard
        import_pb_to_tensorboard.import_to_tensorboard(os.path.join(output_dir,model_name),output_dir)
def main_pb_parse():
    '''pb文件解析'''
    path =r'D:\Jamie\Jupyter\AIproject\KK23\code\training\CCD2_plastic'
    pb = 'RFKK23_CCD2_plastic_finalWeights.pb'
    txt = 'tf.txt'
    graph = load_graph(os.path.join(path,pb))  # 这里传入的是完整的路径包括pb的名字，不然会报FailedPreconditionError
    f = open(os.path.join(path,txt), 'w')
    for op in graph.get_operations():  # 打印出图中的节点信息
        f.write(str(op.name).ljust(60, ' ') + "   " + str(op.values()) + '\n')
    print (op.name, op.values())
    f.close()

def main_pb_gen1():
    '''H5生成Pb文件'''
    model_path = r'D:\Leslie\Project\SKTVBP\BP_model\SKTVBP_CCD1_bubble\SKTVBP_CCD1_bubble\bestcheckpoints\4\SKTVBP_CCD1_bubbleiou0.677-val_iou0.770.h5'
    onnx_path=r'D:\Leslie\Project\SKTVBP\BP_model\SKTVBP_CCD1_bubble\SKTVBP_CCD1_bubble\bestcheckpoints\4\SKTVBP_CCD1_bubble_finalWeights.onnx'
    model = unet_m(992, 800, img_channels=1, label_channels=2)
    model.load_weights(model_path)
    onnx_model=keras2onnx.convert_keras(model,model.name)
    # output_graph_name = 'SKTVBP_CCD1_bubble_finalWeights.pb'
    #json_path = 'LDL2743_architecture.json'
    # h5_to_pb(model_result, output_dir=path, model_name=output_graph_name)
    #model_result = model_from_json(open(os.path.join(path, json_path)).read())
    actual_batch_dim = 1
    inputs = onnx_model.graph.input
    for inp in inputs:
        inp.type.tensor_type.shape.dim[0].dim_value = actual_batch_dim

    outputs=onnx_model.graph.output
    for out in outputs:
        out.type.tensor_type.shape.dim[0].dim_value = actual_batch_dim
    onnx.save_model(onnx_model, os.path.join(onnx_path))
if __name__ == '__main__':
    main_pb_gen1()#





