# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# from keras.layers import Input, merge, Conv2D, MaxPooling2D, UpSampling2D, Lambda, Dropout, SpatialDropout2D, \
#     Convolution2D, concatenate, Conv2DTranspose
# from keras.models import Model
# from keras.models import model_from_json, load_model
# import keras.backend as K
# import numpy as np
# import cv2
import os
# import shutil
# import random
# import json
# import time


os.environ["CUDA_VISIBLE_DEVICES"] = "0"#GPU序号选择

from train import *
# from pb import main_pb_gen1, main_pb_parse
from inference import main_inference

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # main_CCD1_scratch_gray_20210526()#训练
    main_inference()#预测



    # main_CCD1_scratch_20210605()
    #main_CCD1_scratch_20210625_noMask()
    #main_CCD1_DC_20210605()
    #main_CCD1_spot_20210605()
    #main_CCD1_spot_20210605_noMask()
    # main_CCD1_spot_20210605_E11()
    #main_CCD1_scratch_20210605_E11()
    #main_CCD1_spot_20210605_E11_noMask()
    #main_CCD1_scratch_20210605_E11_noMask()

    # main_CCD2_spot_20210605()
    #main_CCD2_spot_whole_20210605()
    #main_CCD2_spot_whole_20210605_noMask()
    # main_CCD2_scratch_20210605()
    # main_CCD2_scratch_whole_20210605()
    # main_CCD2_scratch_whole_20210625_noMask()
    #main_CCD2_plast_damage_20210605()
    #main_CCD2_spot_whole_20210605_E11()
    #main_CCD2_spot_whole_20210605_E11_noMask()
    #main_CCD2_scratch_whole_20210605_E11()
    #main_CCD2_scratch_whole_20210605_E11_noMask()
    #main_CCD2_hole_20210605_E11()

    #main_CCD3_plast_damage_20210605()

    #main_CCD4_plast_damage_20210605()

    #main_CCD5_metal_20210605()
    #main_CCD5_plastic_20210605()
    #main_CCD5_scratch_20210605()

    #train_sktBP.main_CCD1_scratch_20210731()
    #train_sktBP.main_CCD2_scratch_20210731()
    #train_sktBP.main_CCD2_pits_20210731()
    #train_sktBP.main_CCD1_bubble_20210731()
    #train_sktBP.main_CCD1_wx_20210731()

    #train_115X.main_B4_20211006()

    #train_RF_KK23.main_CCD1_bur_20211021()
    #train_RF_KK23.main_CCD1_line_20211021()
    #train_RF_KK23.main_CCD3_locate_20211021()
    #train_RF_KK23.main_CCD2_plastic_20211021()
    #train_RF_KK23.main_CCD1_wx_20211021()
    #train_RF_KK23.main_CCD1_hole_20211021()
    #train_RF_KK23.main_CCD2_hole_20211021()

    #train_ILM.main_CCD1_scratch_20211022()
    #train_ILM.main_CCD2_wx_20211022()
    #train_ILM.main_CCD2_wx_overlap_20211022()
    #train_ILM.main_CCD2_scratch_20211022()

    #train_Lever.main_CCD2_scratch_20211029()

    # main_pb_gen1()
    # main_pb_parse()



# See PyCharm help at https://www.jetbrains.com/help/pycharm/

