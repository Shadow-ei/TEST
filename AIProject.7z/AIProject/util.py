
import json #
import numpy as np#矩阵操作
from PIL import Image, ImageDraw, ImageEnhance #图像处理库
import cv2 #OpenCV
import os, shutil, io, base64 #图像编码
from skimage.util import random_noise


def img_b64_to_arr(img_b64):
    f = io.BytesIO()
    f.write(base64.b64decode(img_b64))
    img_arr = np.array(Image.open(f))
    f.close()
    return img_arr


def img_arr_to_b64(img_arr):
    img_pil=Image.fromarray(img_arr)
    f=io.BytesIO()
    img_pil.save(f, format='PNG')
    img_bin=f.getvalue()
    img_b64=base64.b64encode(img_bin).decode('utf-8')
    #if hasattr(base64, 'encodebytes'):
    #    img_b64 = base64.encodebytes(img_bin)
    #lse:
    #   img_b64 = base64.encodestring(img_bin)
    return img_b64


def json_convert(json_file,img_data, x, y):
    with open(json_file) as f:
        json_data = json.load(f)
        data = img_arr_to_b64(img_data)
        json_data['imageData'] = data
        for shape in json_data['shapes']:
            points = np.array(shape['points'])
            points[:,0] = points[:,0] + x
            points[:,1] = points[:,1] + y
            shape['points'] = points.tolist()
    return json_data


def json_label_to_img_mask(raw_json_path, label_class, label_value, background):
    with open(raw_json_path) as f:
        json_data = json.load(f)
        img_data = img_b64_to_arr(json_data['imageData'])
        if background == 0:
            mask = np.zeros(img_data.shape[:2], dtype=np.uint8)
        else:
            mask = np.ones(img_data.shape[:2], dtype=np.uint8) * 255
        mask = Image.fromarray(mask)
        for shape in json_data['shapes']:
            points = shape['points']
            label = shape['label']
            try:
                shape_type = label_value[label_class.index(label)]
            except:
                continue
            xy = list(map(tuple, points))
            if len(points) == 1:
                continue
            elif len(points) == 2:
                #ImageDraw.Draw(mask).rectangle(xy=xy, outline=shape_type, fill=shape_type)
                _x=xy[0][0]-xy[1][0]
                _y=xy[0][1]-xy[1][1]
                _r=np.sqrt(_x**2+_y**2)
                print([int(xy[0][0]-_r),int(xy[0][1]-_r),int(_r),int(_r)])
                ImageDraw.Draw(mask).ellipse([int(xy[0][0]-_r),int(xy[0][1]-_r),int(xy[0][0]+_r),int(xy[0][1]+_r)],outline=shape_type, fill=shape_type)
            else:
                ImageDraw.Draw(mask).polygon(xy=xy, outline=shape_type, fill=shape_type)
        mask = np.array(mask, dtype='uint8')
    return img_data, mask


def img_to_mask(raw_json_path, save_path, wlen, hlen, wcut=1, hcut=1, top_cut=0, left_cut=0,
                label_class=None, label_value=None, mask_color=None, save_raw_pic = False,
                by_group = False, background = 0):
    '''
    輸入圖片json文件或者圖片文件，以及切割和標註信息，輸出切割的圖片
    :param raw_json_path:
    :param save_path:
    :param wlen:
    :param hlen:
    :param wcut:
    :param hcut:
    :param top_cut:
    :param left_cut:
    :param label_class:
    :param label_value:
    :param mask_color:
    :param save_raw_pic:
    :param by_group:
    :param background:
    :return:
    '''

    if raw_json_path.endswith('.json'):
        img_data, mask = json_label_to_img_mask(raw_json_path, label_class, label_value, background)
        if img_data.ndim ==3:
            img_data = cv2.cvtColor(img_data,cv2.COLOR_BGR2RGB)
        image_name = raw_json_path.split('\\')[-1]
        h, w = img_data.shape[:2]
        #top_cut += np.random.randint(0,40)
        #left_cut += np.random.randint(0, 40)
        if hcut * hlen + top_cut > h or wcut * wlen + left_cut > w:
            raise ValueError("cutting out of range")
        for i in range(hcut):
            for j in range(wcut):
                if background == 0:
                    small_mask = np.zeros((hlen, wlen, 3), dtype=np.uint8)
                elif background == 255:
                    small_mask = np.ones((hlen, wlen, 3), dtype=np.uint8) * 255
                else:
                    raise ValueError("bottom not in [0, 255]")

                small_img = img_data[i * hlen + top_cut:(i + 1) * hlen + top_cut,
                        j * wlen + left_cut:(j + 1) * wlen + left_cut]
                small_mask[:, :, 0] = mask[i * hlen + top_cut:(i + 1) * hlen + top_cut,
                                  j * wlen + left_cut:(j + 1) * wlen + left_cut]
                uni_mask = np.unique(small_mask[:, :, 0])
                if by_group:
                    if len(uni_mask) == 1:
                         path = os.path.join(save_path, 'OK')
                         if not os.path.exists(path):
                            os.makedirs(path)
                    elif len(uni_mask) == 2:
                        N = list(uni_mask).index(background)
                        path = os.path.join(save_path, label_class[label_value.index(uni_mask[1 - N])])
                        if not os.path.exists(path):
                            os.makedirs(path)
                    else:
                        path = os.path.join(save_path, 'multi')
                        if not os.path.exists(path):
                            os.makedirs(path)
                else:
                    path = save_path
                for k in range(len(label_class)):
                    small_mask[:, :, 1] = np.where(small_mask[:, :, 0] == label_value[k], mask_color[k][0],
                                                   small_mask[:, :, 1])
                    small_mask[:, :, 2] = np.where(small_mask[:, :, 0] == label_value[k], mask_color[k][1],
                                                   small_mask[:, :, 2])
                if save_raw_pic:
                    #img_path = os.path.join(path, str(i) + str(j) + '_' + image_name)
                    img_path = os.path.join(path,  image_name.replace('.json','.json'))
                    cv2.imencode('.bmp',small_mask)[1].tofile(img_path.replace('.json', "_"+str(i)+str(j)+'_label.bmp'))
                    cv2.imencode('.bmp', small_img)[1].tofile(img_path.replace('.json', "_"+str(i)+str(j)+'.bmp'))
                else:
                    img_path = os.path.join(path, image_name)
                    cv2.imencode('.bmp', small_mask)[1].tofile(img_path.replace('.json', '_label.bmp'))
    elif raw_json_path[-4:].lower() in ['.bmp', '.png', '.jpg']:
        img_data = cv2.imdecode(np.fromfile(raw_json_path, dtype=np.uint8), -1)
        image_name = raw_json_path.split('\\')[-1]
        image_format = raw_json_path[:-4]
        h, w = img_data.shape[:2]
        if hcut * hlen + top_cut > h or wcut * wlen + left_cut > w:
            raise ValueError("cutting out of range")
        if background == 0:
            mask = np.zeros(img_data.shape[:2], dtype=np.uint8)
        else:
            mask = np.ones(img_data.shape[:2], dtype=np.uint8) * 255
        for i in range(hcut):
            for j in range(wcut):
                if background == 0:
                    small_mask = np.zeros((hlen, wlen, 3), dtype=np.uint8)
                elif background == 255:
                    small_mask = np.ones((hlen, wlen, 3), dtype=np.uint8) * 255
                else:
                    raise ValueError("bottom not in [0, 255]")
                small_img = img_data[i * hlen + top_cut:(i + 1) * hlen + top_cut,
                            j * wlen + left_cut:(j + 1) * wlen + left_cut]
                small_mask[:, :, 0] = mask[i * hlen + top_cut:(i + 1) * hlen + top_cut,
                                      j * wlen + left_cut:(j + 1) * wlen + left_cut]
                img_path = os.path.join(save_path, str(i) + str(j) + '_' + image_name)
                #cv2.imencode('.bmp', small_mask)[1].tofile(img_path.replace(image_format, '_label' + image_format))
                cv2.imencode('.bmp', small_img)[1].tofile(img_path)
    else:
        raise TypeError("format error")



def img_enhance(path_to_image, path_to_enhance, enh='zd') -> object:
    image_name = [x for x in os.listdir(path_to_image) if x.endswith('_label.bmp')]
    image_num = len(image_name)

    for idx in range(image_num):
        image = Image.open(os.path.join(path_to_image, image_name[idx].replace('_label.bmp', '.bmp')))
        mask = Image.open(os.path.join(path_to_image, image_name[idx]))
        #print(image.mode)
        # image=image.convert("L")
        if enh == 'bri':
            enh_bri = ImageEnhance.Brightness(image)  # 亮度增强
            brightness = 1.5
            image_brightened = enh_bri.enhance(brightness)
            image_brightened.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_bri.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_bri_label.bmp')))

        elif enh == 'con':
            enh_con = ImageEnhance.Contrast(image)  # 对比度增强
            contrast = 2
            image_contrasted = enh_con.enhance(contrast)
            image_contrasted.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_con.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_con_label.bmp')))

        elif enh == 'sha':
            enh_sha = ImageEnhance.Sharpness(image)  # 锐度增强
            sharpness = 9.0
            image_sharped = enh_sha.enhance(sharpness)
            image_sharped.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_sha.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_sha_label.bmp')))

        elif enh == 'col':
            enh_col = ImageEnhance.Color(image)  # 色度增强
            color = 1.5
            image_colored = enh_col.enhance(color)
            image_colored.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_col.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_col_label.bmp')))

        elif enh == 'FLR':  # FLIP_LEFT_RIGHT #左右翻转
            image_F = image.transpose(Image.FLIP_LEFT_RIGHT)
            mask_F = mask.transpose(Image.FLIP_LEFT_RIGHT)
            image_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_flr.bmp')))
            mask_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_flr_label.bmp')))

        elif enh == 'FTB':  # FLIP_TOP_BOTTOM #上下翻转
            image_F = image.transpose(Image.FLIP_TOP_BOTTOM)
            mask_F = mask.transpose(Image.FLIP_TOP_BOTTOM)
            image_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_ftb.bmp')))
            mask_F.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', 'z_ftb_label.bmp')))

        elif enh == 'R180':  # ROTATE_180 旋转180度
            image_R = image.transpose(Image.ROTATE_180)
            mask_R = mask.transpose(Image.ROTATE_180)
            image_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r180.bmp')))
            mask_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r180_label.bmp')))

        elif enh == 'R90': #ROTATE_90 旋转90度
            image_R = image.transpose(Image.ROTATE_90)
            mask_R = mask.transpose(Image.ROTATE_90)
            image_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r90.bmp')))
            mask_R.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_r90_label.bmp')))

        elif enh == 'zd':
            image_zd = random_noise(image, 1000)
            image_zd.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_zd.bmp')))
            mask.save(os.path.join(
                path_to_enhance, image_name[idx].replace('_label.bmp', '_zd_label.bmp')))

        else:
            pass

   # def load_image_label_batch(self, label_name, batch_start, batch_end):#载入一batch图片
    #     image = np.zeros([batch_end - batch_start, self.img_h, self.img_w, self.img_channels], dtype=np.float32) #shape(batch_size,h,w,c)比如(12,992,800,1)
    #     label = np.zeros([batch_end - batch_start, self.img_h, self.img_w, self.label_channels], dtype=np.float32)
    #     for i in range(batch_end - batch_start):
    #         if self.img_channels == 1:#通道数判断 读成灰度图 一般是运行这个↓
    #             #读取原图数据，只需要将label_name里存的label标签名称改为.png即可使用绝对路径访问到原图,因为原图和标注图是放在一块的 img维度是(992,800)
    #             img = cv2.imdecode(np.fromfile(label_name[i + batch_start].replace('_label.png', '.png'),dtype=np.uint8), 0)#imdecode,解码函数，一般是读取图片数据 encode是编码函数，是写入图片
    #             img = np.expand_dims(img, axis=2)#shape=(992,800,1)给数组加一个维度，位置为axis=2  如果原来的维度为(x,y) axis=2 则维度变为(x,y,1)-->axis=1-->维度变为(x,1,y,1) 总之就是在axis处添加一个一维的维度
    #         else: #BGR图
    #             img = cv2.imdecode(np.fromfile(label_name[i + batch_start].replace('_label.png', '.png'),dtype=np.uint8), 1)
    #         img = np.array(img/255.,dtype=np.float32)#图片归一化
    #         mask = cv2.imdecode(np.fromfile(label_name[i + batch_start], dtype=np.uint8), 1)#直接读取标注图label
    #         if img is None or mask is None:
    #             print(label_name[i + batch_start])
    #         image[i] = img #1，根据label_name读取原图,然后添加第三个channel维度,然后归一化,最后赋值给image回传给调用处
    #         if self.label_channels > 1:#多分类，运行这个↓
    #             for j in range(self.label_channels):
    #                 label[i][:, :, j] = np.where(mask[:, :, 0] == j, 1, 0)  # 无缺陷放在label0层, 缺陷1放在label1层...  np.where表示如果满足，则输出x，否则输出y
    #         else:#二分类
    #             label[i][:, :, 0] = np.where(mask[:, :, 0] == 1, 1, 0)  # 无缺陷放在label0层, 缺陷都放在label1层... 即阴性样本放在0层，阳性样本放在1层
    #             # label[i][:, :, 1] = np.where(mask[:, :, 0] == 1, 1, 0)
    #     #    md=np.median(image[i])
    #     #    av=np.mean(image[i])
    #     #    a0=np.unique(label[i][...,0])
    #     #    a1=np.unique(label[i][...,1])
    #     #    a2=np.unique(label[i][...,2])
    #     #    a3=np.unique(label[i][...,3])
    #     #    dic={'name':label_name[i+batch_start],'median':md,'mean':av,'a0':a0,'a1':a1,'a2':a2,'a3':a3}
    #     #    l.append(dic)
    #     # with open(str(t)+'.txt','w') as f:
    #     #    f.writelines([str(s) for s in l])
    #     return (image, label)#模型的输入，原图，标注图
