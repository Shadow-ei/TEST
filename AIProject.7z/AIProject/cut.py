# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import PIL.Image
import util
import os, cv2, io, base64, shutil  # 文件处理
import numpy as np
from PIL import Image
import json


def main_enh():  # 图片增强
    """
    圖片增強————bri、sha、com、col
    :return:
    """
    path = r'G:\SKTE_Clip\data\0908\OK\CCD6\NG\loc'  # 选择我们想要增强的图片文件路径
    save_path = r'G:\SKTE_Clip\data\0908\OK\CCD6\NG\loc\hance'  # 存放路径
    util.img_enhance(path, save_path, 'con')  # 选择增强模式，这里是bri亮度增强


def main_img_to_mask_labelME():  # 标注转化图片
    """
    labelME標註轉化圖片
    :return:
    """
    path = r'D:\Leslie\Practice\2021.11.1\KK23\image\20211030\cut'  # 选择之前切割好的图片路径
    save_path = r'D:\Leslie\Practice\2021.11.1\KK23\image\20211030\cut\label'  # 选择图片提取后的存放路径
    for _ in os.listdir(path):
        if _.endswith('.json'):  # 只处理刚刚在labelme标注并存储完成的json文件
            json_path = os.path.join(path, _)  # 获取json文件的位置，一般保存在原图位置
            # 路径       保存路径    图片宽度    图片长度                                             要处理的label类型
            # 不同类型用不同数字代替，背景颜色默认是0黑色   后面两个分别为AB类型的rgb数字，
            util.img_to_mask(json_path, save_path, wlen=1024, hlen=640, wcut=1, hcut=1, top_cut=0, left_cut=0,
                             label_class=['A', 'B'], label_value=[1, 2], mask_color=[[100, 0], [0, 200]],
                             save_raw_pic=True, by_group=True, background=0)
            # 是否保存原图       是否分组显示    背景颜色


def main_label_copy():  # 标注图复制
    """
    標註圖複製
    :return:
    """
    path1 = r'D:\Leslie\Project\KK23\image\20211030\cut\RFKK23_1030-v3-2021-11-02-09-38-36\a58ed3e2-c5ef-4b70-a136-29372a695fda\img'
    path2 = r'D:\Leslie\Project\KK23\image\20211030\cut\RFKK23_1030-v3-2021-11-02-09-38-36\a58ed3e2-c5ef-4b70-a136-29372a695fda\label'
    for _ in os.listdir(path1):
        if _.endswith('.bmp'):
            shutil.copy(os.path.join(path1, _), os.path.join(path2, _))
            # shutil.copy(os.path.join(path1, _), os.path.join(path2, _.replace('.png','.bmp')))
            # img_data = cv2.imdecode(np.fromfile(os.path.join(path1,_),np.uint8),-1)
            # cv2.imencode('.bmp',data)[1].tofile(os.path.join(path1,_.replace('.png','_label.bmp')))


def main_to_mask_landingAI():  # Landing软件的标注转图片
    """
    landingAI標註轉圖片
    :return:
    """
    label_class = {'A': 1}
    path = r'D:\Leslie\Project\KK23\image\20211030\cut\RFKK23_1030-v3-2021-11-02-09-38-36\a58ed3e2-c5ef-4b70-a136-29372a695fda\img'

    parent_path = os.path.dirname(path) + '\\meta.json'
    label_json = 0
    with open(parent_path, errors='ignore') as f:
        label_json = json.load(f)
    label_save_file = os.path.dirname(path) + '\\label'
    if not (os.path.exists(label_save_file)):
        os.makedirs(label_save_file)

    infer_dir = [x for x in os.listdir(path) if x.endswith('.bmp')]
    for x in infer_dir:
        img = cv2.imdecode(np.fromfile(os.path.join(path, x), np.uint8), 0)
        color_small_mask = np.zeros((img.shape[0], img.shape[1], 3), dtype=np.uint8)
        print(x)
        json_file = os.path.join(path, x) + ".meta.json"
        with open(json_file, errors='ignore') as f:
            json_data = json.load(f)
            for pic in json_data['segmentations']:
                mask_name = os.path.join(path, x) + '.label\\' + pic + '.png'

                # mask = cv2.imread(mask_name,0)
                mask = Image.open(mask_name)
                array = np.asarray(mask)
                # cv2.imwrite(r"F:\xiaok.bmp",array[:,:,1:4])
                # mask.save(r"F:\xiaok.bmp")
                mask = cv2.cvtColor(array[:, :, 1:4], cv2.COLOR_RGB2BGR)
                # cv2.imwrite(r"F:\xiaok.bmp",mask)

                mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
                # cv2.imwrite(r"F:\xiaok.bmp",mask)
                defect_i_d = json_data['segmentations'][pic]['defect_i_d']
                label = label_json['defects'][defect_i_d]['name']
                label_value = label_class[label]

                ### 1===red
                if label_value == 1:
                    color_small_mask[:, :, 0][np.where(mask > 0)] = 1
                    color_small_mask[:, :, 1][np.where(mask > 0)] = 0
                    color_small_mask[:, :, 2][np.where(mask > 0)] = 255
                #          2==green
                if label_value == 2:
                    color_small_mask[:, :, 0][np.where(mask > 0)] = 2
                    color_small_mask[:, :, 1][np.where(mask > 0)] = 255
                    color_small_mask[:, :, 2][np.where(mask > 0)] = 0
                #          3== yellow
                if label_value == 3:
                    color_small_mask[:, :, 0][np.where(mask != 255)] = 3
                    color_small_mask[:, :, 1][np.where(mask != 255)] = 255
                    color_small_mask[:, :, 2][np.where(mask != 255)] = 255
                #          4== 粉红
                if label_value == 4:
                    color_small_mask[:, :, 0][np.where(mask != 255)] = 4
                    color_small_mask[:, :, 1][np.where(mask != 255)] = 100
                    color_small_mask[:, :, 2][np.where(mask != 255)] = 255
            cv2.imencode('.png', color_small_mask)[1].tofile(label_save_file + '\\%s' % x[:-4] + '_label.bmp')


def main_seg_img():  # 切割小图
    """
    圖片切割
    :return:
    """
    path1 = r'G:\SKTE_Clip\data\0721\CCD1234\B1'  # 目标图像文件夹位置
    path2 = r'G:\SKTE_Clip\data\0721\CCD1234\B1\cut'  # 切割后的存放位置
    img_top = 412  # 距离图片top高度的纵坐标
    img_left = 360  # 距离图片left左边长度的横坐标
    seg_h = 1  # 高 切割块数
    seg_w = 1  # 宽 切割块数
    small_h = 1264  # 切割后的高度
    small_w = 1680  # 切割后的宽度
    img_channels = 3  # 图层的数量，即rgb的个数
    for _ in os.listdir(path1):  # 通过os这个文件操作库来获取文件夹的所有图片并进行处理
        if _.endswith(".png"):  # 只处理后缀为.bmp的图片
            print(_)
            if img_channels == 1:
                img = cv2.imdecode(np.fromfile(os.path.join(path1, _), np.uint8), 0)
            elif img_channels == 3:
                img = cv2.imdecode(np.fromfile(os.path.join(path1, _), np.uint8), 1)
            else:
                raise ValueError("img channels error")
            img_height, img_width = img.shape[:2]
            if img_height < small_h * seg_h + img_top or img_width < small_w * seg_w + img_left:
                raise ValueError("img size error")
            for i in range(seg_h):
                for j in range(seg_w):
                    cv2.imencode(".png", img[img_top + i * small_h:img_top + (i + 1) * small_h,
                                         img_left + j * small_w:img_left + (j + 1) * small_w])[1].tofile(
                        os.path.join(path2, _.replace(".png", "_" + str(i) + str(j) + ".png")))


def create_label():  # 创建全黑label图
    path = r'D:\Leslie\Project\SKTVBP\BP_model\raw_img\2022-01-03\CCD1\pre\A2\origin\select\s'
    path2 = r'D:\Leslie\Project\SKTVBP\BP_model\raw_img\2022-01-03\CCD1\pre\A2\origin\select\s\label'
    label = np.zeros([992, 800, 3], np.uint8)
    for _ in os.listdir(path):
        if _.endswith(".bmp"):
            cv2.imencode(".bmp", label)[1].tofile(os.path.join(path2, _.replace(".bmp", "_label.bmp")))


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # create_label()#创建全黑label图
    # main_seg_img()#切割小图
    # main_img_to_mask_labelME()#图片标注提取
    main_enh()  # 图片增强
    # main_to_mask_landingAI()
    # main_label_copy()
