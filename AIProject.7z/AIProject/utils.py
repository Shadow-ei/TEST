# -*- coding: utf-8 -*-
'''
# @Time    : 2022/1/14 16:35
# @Author  : Leslie Zou
# @Fuction : 
'''
import os,cv2
# os.environ['TF_KERAS'] = '1'
import numpy as np
import json
import PIL.Image
import PIL.ImageDraw
import os.path
from train import unet_m
import keras2onnx
import onnx


def main_seg_img(img_path,save_path,seg_h,seg_w,img_top,img_left,small_h,small_w,img_type,img_channels):#裁剪图片
    for _ in os.listdir(img_path): #通过os这个文件操作库来获取文件夹的所有图片并进行处理
        if _.endswith(img_type): #只处理后缀为.bmp的图片
            print(_)
            if img_channels==1:
                img=cv2.imdecode(np.fromfile(os.path.join(img_path,_),np.uint8),0)
            elif img_channels==3:
                img = cv2.imdecode(np.fromfile(os.path.join(img_path, _), np.uint8), 1)
            else:
                raise ValueError("img channels error")
            img_height,img_width=img.shape[:2]
            if img_height<small_h*seg_h+img_top or img_width<small_w*seg_w+img_left:
                raise ValueError("img size error")
            for i in range(seg_h):
                for j in range(seg_w):
                    cv2.imencode(img_type,img[img_top+i*small_h:img_top+(i+1)*small_h,img_left+j*small_w:img_left+(j+1)*small_w])[1].tofile(
                        os.path.join(save_path,_.replace(img_type,"_"+str(i)+str(j)+img_type)))

def create_label(img_path,save_path,img_h,img_w,img_type) -> object:#创建全黑label图
    label=np.zeros([img_h,img_w,3],np.uint8)
    for _ in os.listdir(img_path):
        if _.endswith(img_type):
            cv2.imencode(img_type,label)[1].tofile(os.path.join(save_path,_.replace(img_type,"_label"+img_type)))

def json_label_to_img_mask(raw_json_path, label_class,img_ch):
    with open(raw_json_path, errors='ignore') as f:
        json_data = json.load(f)  # 加载json文件的数据内容
        img_path = json_data['imagePath']  # 读取json文件中对应的img原图
        img_type = img_path[-4:]  # 读取类型 img_type:'.bmp'
        img_data = PIL.Image.open(raw_json_path.replace('.json', img_type))
        img_data = np.array(img_data)  # 为img图片路径创建numpy数组信息
        mask = np.zeros(img_data.shape[:2], dtype=np.uint8)  # 根据图片的width和height创建全黑label图
        mask = PIL.Image.fromarray(mask)  # 将array转换成image  将img转化为array：img = np.asarray(image)
        a = 1
        for shape in json_data['shapes']:
            points = shape['points']  # 读取json文件中描绘的点集
            xy = list(map(tuple, points))  # 用元组存储点集
            label = shape['label']  # 读取标签类型'B1'
            shape_type = label_class[label]  # label_class = {'B1':1,'B2':2} 这里label索引为'B1',故shape_type=1
            if len(points) == 2:
                PIL.ImageDraw.Draw(mask).rectangle(xy[0] + xy[1], outline=shape_type, fill=shape_type)
            if len(points) > 2:
                PIL.ImageDraw.Draw(mask).polygon(xy=xy, outline=shape_type, fill=shape_type)  # 在mask中画图
            a += 1
        mask = np.array(mask, dtype=int)
        if(img_ch==3):
            return img_data[:, :, ::-1], mask
        else:
            return img_data, mask

def json_to_mask(json_path, save_path, seg_h, seg_w ,img_type,img_ch) -> object:
    label_class = {'B1': 1, 'B2': 2}
    image_name = os.listdir(json_path)
    image_name = [x for x in image_name if x.endswith('.json')]
    print(len(image_name))
    print(image_name[0])
    m = 1
    for _ in range(len(image_name)):
        img_data, mask = json_label_to_img_mask(os.path.join(json_path, image_name[_]), label_class,img_ch)
        img_height = int(img_data.shape[0] / seg_h)
        img_width = int(img_data.shape[1] / seg_w)
        a = 1
        for i in range(seg_h):
            for j in range(seg_w):
                small_pic = img_data[i * img_height:(i + 1) * img_height, j * img_width:(j + 1) * img_width]
                small_mask = mask[i * img_height:(i + 1) * img_height, j * img_width:(j + 1) * img_width]
                if len(np.unique(small_mask)) == 1:
                    print(m)
                    m += 1
                    path = os.path.join(save_path, 'ok')
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', img_type), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label'+img_type), small_mask)
                elif len(np.unique(small_mask)) == 2:
                    print(m)
                    m += 1
                    color_small_mask = np.zeros((img_height, img_width, 3), dtype=np.uint8)
                    color_small_mask[:, :, 0] = small_mask
                    ### 1===red
                    color_small_mask[:, :, 1][np.where(small_mask == 1)] = 0
                    color_small_mask[:, :, 2][np.where(small_mask == 1)] = 255
                    #          2==green
                    color_small_mask[:, :, 1][np.where(small_mask == 2)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 2)] = 0
                    #          3== yellow
                    color_small_mask[:, :, 1][np.where(small_mask == 3)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 3)] = 255
                    #          4== 粉红
                    color_small_mask[:, :, 1][np.where(small_mask == 4)] = 100
                    color_small_mask[:, :, 2][np.where(small_mask == 4)] = 255

                    color_small_mask[:, :, 1][np.where(small_mask == 5)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 5)] = 100
                    class_type = list(label_class.keys())[list(label_class.values()).index(np.unique(small_mask)[1])]

                    path = os.path.join(save_path, class_type)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', img_type), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label'+img_type), color_small_mask)
                else:
                    print(m)
                    m += 1
                    color_small_mask = np.zeros((img_height, img_width, 3), dtype=np.uint8)
                    color_small_mask[:, :, 0] = small_mask
                    #1===red
                    color_small_mask[:, :, 1][np.where(small_mask == 1)] = 0
                    color_small_mask[:, :, 2][np.where(small_mask == 1)] = 255
                    #2==green
                    color_small_mask[:, :, 1][np.where(small_mask == 2)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 2)] = 0
                    #3== yellow
                    color_small_mask[:, :, 1][np.where(small_mask == 3)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 3)] = 255
                    #4== 粉红
                    color_small_mask[:, :, 1][np.where(small_mask == 4)] = 100
                    color_small_mask[:, :, 2][np.where(small_mask == 4)] = 255
                    #4== red
                    color_small_mask[:, :, 1][np.where(small_mask == 5)] = 255
                    color_small_mask[:, :, 2][np.where(small_mask == 5)] = 100
                    path = os.path.join(save_path, 'mulit_type')
                    if not os.path.exists(path):
                        os.makedirs(path)
                    img_path = os.path.join(path, str(a) + '_' + image_name[_])
                    cv2.imwrite(img_path.replace('.json', img_type), small_pic)
                    cv2.imwrite(img_path.replace('.json', '_label'+img_type), color_small_mask)
                a += 1

def h5_to_onnx(model_path,onnx_path,img_h,img_w,img_channels) -> object:#H5生成onnx文件
    model = unet_m(img_h, img_w, img_channels, label_channels=2)
    model.load_weights(model_path)
    onnx_model=keras2onnx.convert_keras(model,model.name)
    actual_batch_dim = 1
    inputs = onnx_model.graph.input
    for inp in inputs:
        inp.type.tensor_type.shape.dim[0].dim_value = actual_batch_dim
    outputs=onnx_model.graph.output
    for out in outputs:
        out.type.tensor_type.shape.dim[0].dim_value = actual_batch_dim
    onnx.save_model(onnx_model, os.path.join(onnx_path))