﻿using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Client.Options;
using System;
using System.Text;
using System.Threading.Tasks;

namespace MQTTtestConsoleApp1
{
    class Program
    {
        private static void MqqtClientTest()
        {
            var mqttClient = new MqttFactory().CreateMqttClient();

            mqttClient.UseConnectedHandler(
                args =>
                {
                    var topicFilter = new MqttTopicFilter();
                    topicFilter.Topic = "FEA_Client";
                    mqttClient.SubscribeAsync(topicFilter);
                    Console.WriteLine("connected.");
                });
            mqttClient.UseDisconnectedHandler(
                args =>
                {
                    Console.WriteLine("disconnected.");
                });
            mqttClient.UseApplicationMessageReceivedHandler(
                args =>
                {
                    string content = Encoding.UTF8.GetString(args.ApplicationMessage.Payload);
                    Console.WriteLine($"主题：{args.ApplicationMessage.Topic} 收到消息：{content}");

                    //mqttClient.PublishAsync("itpow/2/", "ok"); // 再转发一个。
                });

            IMqttClientOptions options = new MqttClientOptionsBuilder()
                .WithTcpServer("127.0.0.1", 1883)
                //.WithWebSocketServer("ws://127.0.0.1:9000/ws")
                .WithClientId("MQTT_FX_Client")
                .WithCredentials("fea", "fea123456")
                .WithCleanSession()
                .Build();
            mqttClient.ConnectAsync(options);
        }
        static void Main(string[] args)
        {
            Task.Run(() =>
            {
                MqqtClientTest();
            });
            Console.ReadLine();
            Console.WriteLine("Hello World!");
        }
    }
}
