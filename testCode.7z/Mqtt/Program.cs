﻿using MQTTnet;
using MQTTnet.Protocol;
using MQTTnet.Server;
using System;
using System.Threading.Tasks;

namespace Mqtt
{
    class Program
    {
        private static void MqqtServerTest()
        {

            var options = new MqttServerOptions();
            options.DefaultEndpointOptions.Port = 1883;
            options.ConnectionValidator = new MqttServerConnectionValidatorDelegate((context) => {
                if ((context.Username != "fea" || context.Password != "fea123456") &&
                    (context.Username != "fea2" || context.Password != "fea123456"))
                {

                    context.ReasonCode = MqttConnectReasonCode.BadUserNameOrPassword;
                }
                else Console.Write("Nooooo");
            });

            var mqttServer = new MqttFactory().CreateMqttServer();
            mqttServer.UseClientConnectedHandler(ClientConnected);
            mqttServer.UseClientDisconnectedHandler(ClientDisconnected);
            mqttServer.ClientSubscribedTopicHandler = new MqttServerClientSubscribedTopicHandlerDelegate(ClientSubscribed);
            mqttServer.UseApplicationMessageReceivedHandler(MessageReceived);
            mqttServer.StartAsync(options);
        }


        private static Task ClientConnected(MqttServerClientConnectedEventArgs args)
        {
            return Task.Run(() => {
                // args.ClientId
                Console.Write(args.ClientId);
            });
        }


        private static Task ClientDisconnected(MqttServerClientDisconnectedEventArgs args)
        {
            return Task.Run(() => {
                // args.ClientId
                Console.Write(args.ClientId);
            });
        }


        private static void ClientSubscribed(MqttServerClientSubscribedTopicEventArgs args)
        {
            // args.ClientId
            // args.TopicFilter.Topic
            Console.Write(args.ClientId, args.TopicFilter.Topic);
        }


        private static Task MessageReceived(MqttApplicationMessageReceivedEventArgs args)
        {
            return Task.Run(() => {
                // args.ClientId
                // args.ApplicationMessage.Topic
                // args.ApplicationMessage.ConvertPayloadToString()
                Console.Write(args.ClientId, args.ApplicationMessage.Topic, args.ApplicationMessage.ConvertPayloadToString());
            });
        }

        static void Main(string[] args)
        {
            Task.Run(() =>
            {
                MqqtServerTest();
            });
            Console.ReadLine();
        }
    }
}
